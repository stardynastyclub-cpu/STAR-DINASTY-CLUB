package com.example.proyecto_4b

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// Nuevas librerias
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    // 1. Declaración de las cajas de texto
    private var txtIdUsuario: EditText? = null
    private var txtPrimerNombre: EditText? = null
    private var txtSegundoNombre: EditText? = null
    private var txtPrimerApellido: EditText? = null
    private var txtSegundoApellido: EditText? = null
    private var txtCorreo: EditText? = null
    private var txtContrasena: EditText? = null
    private var txtEstado: EditText? = null
    private var btnInsertar: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // 2. Enlazamos los componentes usando los IDs que creaste en tu XML (activity_main.xml)
        txtIdUsuario = findViewById(R.id.id_usuario)
        txtPrimerNombre = findViewById(R.id.primer_nom)
        txtSegundoNombre = findViewById(R.id.segundo_nom)
        txtPrimerApellido = findViewById(R.id.primer_apelli)
        txtSegundoApellido = findViewById(R.id.segundo_apelli)
        txtCorreo = findViewById(R.id.correo)
        txtContrasena = findViewById(R.id.contrasena)
        txtEstado = findViewById(R.id.estado)
        btnInsertar = findViewById(R.id.btn_insertarusu)

        // 3. Configuramos la acción del botón al hacer clic
        btnInsertar?.setOnClickListener {
            clickBtnInsertar()
        }
    }
    private fun clickBtnInsertar() {
        // 1. Definimos la URL de tu servicio PHP local
        val url = "http://10.0.2.2/api_rest/insercion.php"
        // 2. Inicializamos la cola de peticiones de Volley
        val queue = com.android.volley.toolbox.Volley.newRequestQueue(this)

        // 3. Creamos el StringRequest apuntando al método POST
        val resultadoPost = object : com.android.volley.toolbox.StringRequest(
            com.android.volley.Request.Method.POST, url,
            com.android.volley.Response.Listener<String> { response ->
                // Se ejecuta cuando el servidor PHP responde con éxito
                android.widget.Toast.makeText(
                    this,
                    "Usuario insertado exitosamente: $response",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            },
            com.android.volley.Response.ErrorListener { error ->
                // Se ejecuta si hay un error de conexión o de red
                android.widget.Toast.makeText(
                    this,
                    "Error al conectar: ${error.message}",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        ) {
            // 4. Aquí mapeamos las variables de Android con los nombres que espera tu script PHP
            override fun getParams(): MutableMap<String, String> {
                val parametros = HashMap<String, String>()

                // Pasamos los textos de tus campos visuales a la petición de red
                // Las claves coinciden perfectamente con tu base de datos de libros
                parametros.put("id_usuario", txtIdUsuario?.text.toString().trim())
                parametros.put("primer_nom", txtPrimerNombre?.text.toString().trim())
                parametros.put("segundo_nom", txtSegundoNombre?.text.toString().trim())
                parametros.put("primer_apelli", txtPrimerApellido?.text.toString().trim())
                parametros.put("segundo_apelli", txtSegundoApellido?.text.toString().trim())
                parametros.put("correo", txtCorreo?.text.toString().trim())
                parametros.put("contrasena", txtContrasena?.text.toString().trim())
                parametros.put("estado", txtEstado?.text.toString().trim())

                return parametros
            }
        }

        // 5. Agregamos la petición a la cola para que se envíe a MySQL
        queue.add(resultadoPost)
    }
}
CREATE DATABASE STARDINASTY;
USE STARDINASTY;

CREATE TABLE rol(
    id_rol INT NOT NULL,
    nombre_rol VARCHAR(40) NOT NULL,
    estado CHAR(1) DEFAULT 'A',
    PRIMARY KEY(id_rol)
);
CREATE TABLE usuario(
    id_usuario INT NOT NULL,
    id_rol INT NOT NULL,
    primer_nom VARCHAR(25) NOT NULL,
    segundo_nom VARCHAR(25),
    primer_apelli VARCHAR(25) NOT NULL,
    segundo_apelli VARCHAR(25),
    correo VARCHAR(100) NOT NULL,
    contrasena VARCHAR(60) NOT NULL,
    estado CHAR(1) DEFAULT 'A',
    PRIMARY KEY(id_usuario)
);

CREATE TABLE administrador(
    fkpk_id_administrador INT NOT NULL,
    PRIMARY KEY(fkpk_id_administrador)
);

CREATE TABLE empleado(
    fkpk_id_empleado INT NOT NULL,
    PRIMARY KEY(fkpk_id_empleado)
);

CREATE TABLE cliente(
    fkpk_id_cliente INT NOT NULL,
    PRIMARY KEY(fkpk_id_cliente)
);

CREATE TABLE categoria(
    id_categoria INT NOT NULL,
    nombre VARCHAR(45) NOT NULL,
    descripcion VARCHAR(55),
    PRIMARY KEY(id_categoria)
);

CREATE TABLE productos(
    id_producto INT NOT NULL,
    id_categoria INT NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(55),
    precio MEDIUMINT NOT NULL,
    estado CHAR(1) DEFAULT 'A',
    PRIMARY KEY(id_producto)
);

CREATE TABLE inventario(
    id_inventario INT NOT NULL,
    id_producto INT NOT NULL,
    stock_actual INT NOT NULL,
    stock_minimo INT NOT NULL,
    PRIMARY KEY(id_inventario)
);

CREATE TABLE movimientos_inventario(
    id_movimiento INT NOT NULL,
    id_inventario INT NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    cantidad INT NOT NULL,
    fecha DATETIME NOT NULL,
    PRIMARY KEY(id_movimiento)
);

CREATE TABLE ventas(
    id_venta INT NOT NULL,
    id_cliente INT NOT NULL,
    id_empleado INT NOT NULL,
    fecha DATETIME NOT NULL,
    total MEDIUMINT NOT NULL,
    estado CHAR(1) DEFAULT 'A',
    PRIMARY KEY(id_venta)
);

CREATE TABLE detalle_venta(
    id_detalle INT NOT NULL,
    id_venta INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario MEDIUMINT NOT NULL,
    subtotal MEDIUMINT NOT NULL,
	total MEDIUMINT NOT NULL,
    PRIMARY KEY(id_detalle)
);

CREATE TABLE facturas(
    id_factura INT NOT NULL,
	id_venta INT NOT NULL,
    fecha DATETIME NOT NULL,
    total MEDIUMINT NOT NULL,
    PRIMARY KEY(id_factura)
);

CREATE TABLE imagenes_producto(
    id_imagen INT NOT NULL,
    id_producto INT NOT NULL,
    ruta_imagen VARCHAR(255) NOT NULL,
    PRIMARY KEY(id_imagen)
);

ALTER TABLE usuario
ADD CONSTRAINT fk_usuario_rol
FOREIGN KEY (id_rol)
REFERENCES rol(id_rol);

ALTER TABLE administrador
ADD CONSTRAINT fk_admin_usuario
FOREIGN KEY (fkpk_id_administrador)
REFERENCES usuario(id_usuario);

ALTER TABLE empleado
ADD CONSTRAINT fk_empleado_usuario
FOREIGN KEY (fkpk_id_empleado)
REFERENCES usuario(id_usuario);

ALTER TABLE cliente
ADD CONSTRAINT fk_cliente_usuario
FOREIGN KEY (fkpk_id_cliente)
REFERENCES usuario(id_usuario);

ALTER TABLE productos
ADD CONSTRAINT fk_producto_categoria
FOREIGN KEY (id_categoria)
REFERENCES categoria(id_categoria);

ALTER TABLE inventario
ADD CONSTRAINT fk_inventario_producto
FOREIGN KEY (id_producto)
REFERENCES productos(id_producto);

ALTER TABLE movimientos_inventario
ADD CONSTRAINT fk_movimiento_inventario
FOREIGN KEY (id_inventario)
REFERENCES inventario(id_inventario);

ALTER TABLE ventas
ADD CONSTRAINT fk_venta_cliente
FOREIGN KEY (id_cliente)
REFERENCES cliente(fkpk_id_cliente);

ALTER TABLE ventas
ADD CONSTRAINT fk_venta_empleado
FOREIGN KEY (id_empleado)
REFERENCES empleado(fkpk_id_empleado);

ALTER TABLE detalle_venta
ADD CONSTRAINT fk_detalle_venta
FOREIGN KEY (id_venta)
REFERENCES ventas(id_venta);

ALTER TABLE detalle_venta
ADD CONSTRAINT fk_detalle_producto
FOREIGN KEY (id_producto)
REFERENCES productos(id_producto);

ALTER TABLE facturas
ADD CONSTRAINT fk_factura_venta
FOREIGN KEY (id_venta)
REFERENCES ventas(id_venta);

ALTER TABLE imagenes_producto
ADD CONSTRAINT fk_imagen_producto
FOREIGN KEY (id_producto)
REFERENCES productos(id_producto);

<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "conexion.php";

    $idusuario     = $_POST["id_usuario"];
    $primernom     = $_POST["primer_nom"];
    $segundonom    = $_POST["segundo_nom"];
    $primerapelli  = $_POST["primer_apelli"];
    $segundoapelli = $_POST["segundo_apelli"];
    $correo        = $_POST["correo"];
    $contrasena    = $_POST["contrasena"];
    $estado        = $_POST["estado"];

    $query = "INSERT INTO usuario 
              (id_usuario, primer_nom, segundo_nom, primer_apelli, segundo_apelli, correo, contrasena, estado)
              VALUES ('$idusuario', '$primernom', '$segundonom', '$primerapelli', '$segundoapelli', '$correo', '$contrasena', '$estado')";

    $resultado = $mysql_conn->query($query);

    if($resultado == TRUE) {
        echo "Usuario registrado exitosamente.";
    } else {
        echo "Error: " . $mysql_conn->error;
    }
}
?>
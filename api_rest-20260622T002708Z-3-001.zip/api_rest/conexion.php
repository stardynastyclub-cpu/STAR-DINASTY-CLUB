<?php
    $host="localhost";
    $user="root";
    $password="";
    $db="STARDINASTYCLUB";

    $mysql_conn = new mysqli($host, $user, $password, $db);

    if ($mysql_conn->connect_error) {
        die("Error de conexion");
    } else{
        echo "Conexion exitosa";
    }
?>